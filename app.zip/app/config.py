config = {
    'host': 'localhost',
    'user': 'postgres',
    'password': '123',
    'database': 'clinic'
}